# auto-ENRICH
automated Experimental Nuclear Resonance Information Calculated with HPC
